package validator

const (
	envVarT2SSchemaDir = "SCHEMA_DIR_T2S"
	envVarISOSchemaDir = "SCHEMA_DIR_ISO"
)
